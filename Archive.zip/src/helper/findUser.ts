import { user } from "../models/user";
import { sendMailToUser } from "../sendmail";

export const findUser = async () => {
    const today = new Date();

    const currDate = today.getDate();
    const currMonth = today.getMonth();
    console.log(`today date is ${currDate},${currMonth}`);

    const allUsers = await user.find();

    //find user based on their birthday
    const birthUsers = allUsers.filter(item => {
        const userBirthDate = item.birthday?.getDate();
        let userBirthMonth = item.birthday ? item.birthday.getMonth() : "";
        console.log(`user birthdate is ${userBirthDate},${userBirthMonth}`);

        if (userBirthDate === currDate && userBirthMonth === currMonth) {
            return item;
        }
    })


    //find user based on their work anniversery
    const workAnniversaryUser = allUsers.filter(item => {
        let userWorkAnniversyDate = item.joiningDate?.getDate();
        let userWorkAnniversyMonth = item.joiningDate ? item.joiningDate.getMonth()  : "";

        console.log(`user work anniversy date is ${userWorkAnniversyDate},${userWorkAnniversyMonth}`);

        if (userWorkAnniversyDate === currDate && userWorkAnniversyMonth === currMonth) {
            console.log(item);
            return item;
        }
    })


    if (birthUsers) {
        birthUsers.map((individual) => {
            sendMailToUser(individual, 'birthday');
        })
    }

    if (workAnniversaryUser) {
        workAnniversaryUser.map((individual) => {
            sendMailToUser(individual, 'work_anniversy');
        })
    }
}